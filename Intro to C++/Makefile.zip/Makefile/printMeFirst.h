#ifndef PRINTMEFIRTS_H
#define  PRINTMEFIRTS_H
#include <string>
using namespace std;

void printMeFirst(string name, string courseInfo);

#endif

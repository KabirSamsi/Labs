#include <string>

using namespace std;

struct Student {
    string name;
    int idNum, creditHours;
    double gpa;
};
#include <string>

using namespace std;

/**
  @Purpose - struct stores data on students
  @author - Kabir Samsi
**/

struct Student {
    string name;
    int idNum, creditHours;
    double gpa;
};